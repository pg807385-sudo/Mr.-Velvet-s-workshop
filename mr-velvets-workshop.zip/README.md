# Mr. Velvet's Workshop

First-person stealth horror. Escape Route A: find the Elevator Crank, Generator Fuse and Fuel Can, start the generator, crank the freight elevator.

## Play in a browser
Open `index.html` (needs internet once to load three.js unless `three.min.js` sits beside it). Best in landscape on a phone.

## Build the Android APK (GitHub Actions)
1. Create a new GitHub repo and upload this zip file itself (`mr-velvets-workshop.zip`) to the repo root.
2. Add the workflow file `.github/workflows/build-apk.yml` (included here and as a separate download).
3. Actions tab, run "Build APK", then download the `velvets-workshop-apk` artifact and install the APK.

Not built yet: escape routes B and C, bear traps, the Spring-Grip tool, cassette tapes.

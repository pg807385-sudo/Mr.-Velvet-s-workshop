# Mr. Velvet's Workshop

First-person stealth horror. Escape Route A: find the Elevator Crank, Generator Fuse and Fuel Can, start the generator, crank the freight elevator.

## Play in a browser
Open `index.html` (needs internet once to load three.js unless `three.min.js` sits beside it). Best in landscape on a phone. Resolution adapts automatically; the corner shows fps.

## Build the Android APK (GitHub Actions)
1. Create a new GitHub repo and upload this zip file itself (`mr-velvets-workshop.zip`) to the repo root.
2. Add the workflow file `.github/workflows/build-apk.yml` (included here and as a separate download).
3. Actions tab, run "Build APK", then download the `velvets-workshop-apk` artifact and install the APK.

Cutscenes: opening cinematic, first encounter (take the Spring-Grip Tool from the workshop bench), vault reveal (Vault Key from the generator room), Ending A and the Day 5 bad ending. Skip button on every scene.

Round 2: interactive doors (they creak, and Mr. Velvet opens them too), four notes, an office safe, a generator circuit puzzle, a music-lock main door escape (Ending D), richer lighting, rugs, dust and wall panelling.

Round 3: adaptive chase music (stinger, driving beat, distorted lullaby), heartbeat, directional footsteps, a taller and scarier Mr. Velvet who stops to listen, and a jump-scare when he catches you.

Not built yet: escape routes B and C, bear traps, the Spring-Grip grab ability, cassette tapes.
